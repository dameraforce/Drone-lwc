declare module "@salesforce/resourceUrl/leaflet" {
    var leaflet: string;
    export default leaflet;
}
